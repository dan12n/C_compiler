int main() {
	return 100 / 11;
}