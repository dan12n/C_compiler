int main() {
	return 7 * 13;
}