int main() {
	return 100 % 7;
}