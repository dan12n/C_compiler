int main() {
	int t = 600;
	int y = 110;

	int z = t != y;

	return z;
}