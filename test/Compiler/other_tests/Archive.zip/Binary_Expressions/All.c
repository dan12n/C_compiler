int main () {
	int x = 120;
	int y = 213;

	int z = (x < y) >= 0;

	int t = 20;

	t = (t <= z); 
	
    return t;
}