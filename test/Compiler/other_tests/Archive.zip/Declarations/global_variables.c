int x = 5;
int y = 8;

int main() {
	int z = x + 1;
	x = 4;

	int t = y * 13;

	return z + t;
}