int main() {
	int y;
	int x;

	x = y = 10;

	int f = x  + 3;

	return f;
}