int main() {
	int x = 7;
	return x;
}