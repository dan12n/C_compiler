int main() {
	int x = (73 * 1) + 7;
	int y = (x * 2) + (30 - 15);
	int z = x + 30;
	return y;
}