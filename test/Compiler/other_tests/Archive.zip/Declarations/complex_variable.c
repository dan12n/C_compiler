int main() {
	int x = 73 * 18 / 30;
	int y = x;
	return y;
}