int x = 5;

int main() {
	int y = 10;
	return x + y;
}