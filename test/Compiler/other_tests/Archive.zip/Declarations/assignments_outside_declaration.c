int main() {
	int t;
	int x = (73 * 1) + 7;
	int y;


	y = ((x * 2) + (30 - 15));
	//It is wrong here!!!
	//Answer from expression does not go to y - it goes to 2

	t = y;
	return y;
}