int main() {
	int i =0;
	int n = 111;

	for (i = 2; i < 10; i++) {
		n--;
	}

	return n;
}