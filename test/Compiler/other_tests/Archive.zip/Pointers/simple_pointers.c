int main()
{
   /*Pointer of integer type*/
   int *p;

   int var = 10;

   /*Assigning the variable address to pointer*/
   p= &var;

   return *p;

}