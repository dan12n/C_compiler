int main () {
	int i = 9;
	int b = 10;
	return b;
}

int tao() {
	int t = 0;
	t++;
	return t;
}