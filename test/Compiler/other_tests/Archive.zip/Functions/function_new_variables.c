int zz() {
	int a = 5;
	int b = 8;

	return a + b;
}

int main() {
	int a = 3;
	int b = 5;
	int c = 8;
	int t = zz();

	return a + b;
}