int kk();

int main() {
	int x = 5;

	return kk();
	int t = 2;
}

int kk() {
	int x = 2;
	return (x*5+12 / 5);
}