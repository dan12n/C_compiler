int zz() {
	int h = 5;
	int k = 8;

	return h + k;
}

int main() {
	int a = 3;
	int b = 5;
	int c = 8;
	return zz();
	int t = 5;
}