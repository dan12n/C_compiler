int main()
{
    int i = 0;

    while ( i < 10 )
    {
       i++;
    }

    return i;
}