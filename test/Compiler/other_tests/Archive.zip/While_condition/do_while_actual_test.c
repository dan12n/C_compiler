int main() {
	int h = 0, x =0;

	do {
		x += 30;
	} while (h > 0);

	while (h > 0) {
	    x += 30;   
	}
	
	return x;

}