int main () {

   /* local variable definition */
   int a = 100;
 
   /* check the boolean condition */
   if( a < 20 ) {
      /* if condition is true then print the following */
      return a;
   }
   else {
      /* if condition is false then print the following */
      return 3000;
   }

   int t = 100;
 
   return 0;
}