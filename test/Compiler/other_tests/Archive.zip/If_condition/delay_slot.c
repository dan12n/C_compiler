int main() {
	int i = 0;

	if (i < 10) {
		i++;
	}

	return i;
}