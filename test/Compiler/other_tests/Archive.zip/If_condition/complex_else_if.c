int main () {

   /* local variable definition */
   int a = 100;
 
   /* check the boolean condition */
   if( a == 10 ) {
      /* if condition is true then print the following */
      return a;
   }
   else if( a == 20 ) {
      /* if else if condition is true */
      return a;
   }
   else if( a == 30 ) {
      /* if else if condition is true  */
      return a;
   }

   else if( a && 30 ) {
      /* if else if condition is true  */
      return a;
   }
   else {
      /* if none of the conditions is true */
      return 3000;
   }

}