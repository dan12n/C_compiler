int main() {
	int x = 10;
	int y = 30;

	if (x != y) {
		y = 20;
	}

	return y;
}