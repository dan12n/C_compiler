int main() {
	int i = 100;

	i += 2;

	i += 7;

	i *= 2;

	i -= 1;


	return i;
}