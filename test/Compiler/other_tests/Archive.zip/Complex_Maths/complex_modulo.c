int main() {
	int a = 13;

	int b = 5;

	int c = a % b;

	if (c < 5) {
		return c;
	}
	return 0;
}