int main()
{
	int b;
	int c = 100;
	int d = 50, k = 10, f = 11;

  	b = d < c ? k : f;

  	return b;
}

//int hello_world(int c,int d)
//{
//  b = d < c ? k<5 : f ? a : 5;
//}
//
//int hello_world(int c,int d)
//{
//  b = d < c ? k==5 : f ? a : 5;
//}
//