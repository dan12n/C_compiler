int main() {
	int i = 99;

	i ++;

	++i;

	i++;

	i--;

	--i;

	return i;
}