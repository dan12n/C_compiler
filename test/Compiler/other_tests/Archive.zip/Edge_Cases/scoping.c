int main () {
	int a = 9;

	if (a < 10) {
		int b = 5;
	}

	return b;
}