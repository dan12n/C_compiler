int factorial(int i);

int  main() {
   int i = 7;

   return !(4 == factorial(i));
}