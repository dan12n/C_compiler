int f();
int z = 20;

int main() {

	return !(30 == f());

}