int f();

int main()
{
    return !( 30 == f() );
}