int main() {
	return !(57 == f());
}