int f();

int main()
{
    return !( 5 == f() );
}