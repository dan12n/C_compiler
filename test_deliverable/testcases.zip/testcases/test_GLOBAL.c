int z;

int f() {
	int a = z;
	z = 10;
	return z+a;
}