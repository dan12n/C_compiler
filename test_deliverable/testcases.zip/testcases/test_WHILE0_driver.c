int f();

int main()
{
    return !( 0 == f() );
}