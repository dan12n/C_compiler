int f()
{
    if (1) {
    	return 30;
    }
    return 10;
}
