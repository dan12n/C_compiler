int f() {
	while (0) {
		return 5;
	}
	return 0;
}