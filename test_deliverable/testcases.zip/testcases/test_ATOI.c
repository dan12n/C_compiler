int atoi(const char* my_char);

int f() {
	const char *in_char = "57";

	return atoi(in_char);
}