int f()
{
    if (0) {
    	return 30;
    }
    return 10;
}
