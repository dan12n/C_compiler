int f()
{
    if (1) {
    	return 30;
    }
    else {
    	return 10;
	}

	return 5;
}
